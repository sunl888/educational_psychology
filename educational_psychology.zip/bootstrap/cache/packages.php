<?php return array (
  'appstract/laravel-opcache' => 
  array (
    'providers' => 
    array (
      0 => 'Appstract\\Opcache\\OpcacheServiceProvider',
    ),
  ),
  'appstract/lush-http' => 
  array (
    'aliases' => 
    array (
      'Lush' => 'Appstract\\LushHttp\\LushFacade',
    ),
  ),
  'barryvdh/laravel-ide-helper' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\LaravelIdeHelper\\IdeHelperServiceProvider',
    ),
  ),
  'davejamesmiller/laravel-breadcrumbs' => 
  array (
    'providers' => 
    array (
      0 => 'DaveJamesMiller\\Breadcrumbs\\BreadcrumbsServiceProvider',
    ),
    'aliases' => 
    array (
      'Breadcrumbs' => 'DaveJamesMiller\\Breadcrumbs\\Facades\\Breadcrumbs',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'mews/captcha' => 
  array (
    'providers' => 
    array (
      0 => 'Mews\\Captcha\\CaptchaServiceProvider',
    ),
    'aliases' => 
    array (
      'Captcha' => 'Mews\\Captcha\\Facades\\Captcha',
    ),
  ),
  'overtrue/laravel-filesystem-qiniu' => 
  array (
    'providers' => 
    array (
      0 => 'Overtrue\\LaravelFilesystem\\Qiniu\\QiniuStorageServiceProvider',
    ),
  ),
  'overtrue/laravel-lang' => 
  array (
    'providers' => 
    array (
      0 => 'Overtrue\\LaravelLang\\TranslationServiceProvider',
    ),
  ),
  'overtrue/laravel-pinyin' => 
  array (
    'providers' => 
    array (
      0 => 'Overtrue\\LaravelPinyin\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Pinyin' => 'Overtrue\\LaravelPinyin\\Facades\\Pinyin',
    ),
  ),
  'spatie/laravel-permission' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Permission\\PermissionServiceProvider',
    ),
  ),
  'ty666/cdn-pusher' => 
  array (
    'providers' => 
    array (
      0 => 'Ty666\\CdnPusher\\CdnPusherServiceProvider',
    ),
  ),
  'ty666/laravel-ueditor' => 
  array (
    'providers' => 
    array (
      0 => 'Overtrue\\LaravelUEditor\\UEditorServiceProvider',
    ),
  ),
);