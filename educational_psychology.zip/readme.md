# Tiny is a simple CMS!
[wiki](https://github.com/3tnet/tiny/wiki)

# screenshots
<img src="https://github.com/3tnet/tiny/blob/develop/screenshots/login.png" />
<img src="https://github.com/3tnet/tiny/blob/develop/screenshots/index.png" />
<img src="https://github.com/3tnet/tiny/blob/develop/screenshots/category.png" />
<img src="https://github.com/3tnet/tiny/blob/develop/screenshots/user.png" />
<img src="https://github.com/3tnet/tiny/blob/develop/screenshots/link.png" />
