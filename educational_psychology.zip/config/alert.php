<?php
return [
    'default_type' => 'info',
    'default_has_button' => false,
    'default_need_container' => true,
    'allow_type_list' => [
        'info', 'success', 'warning', 'danger'
    ]
];