<?php

return [
    'root_namespace' => 'App\Widgets'
];
