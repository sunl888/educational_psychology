<?php

namespace Tests\Unit\Models;


use Tests\TestCase;

class UserTest extends TestCase
{
    public function testUserRole()
    {


    }
}