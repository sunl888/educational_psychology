<?php

namespace Tests\Unit\Models;


use App\Models\Category;
use App\Models\Post;
use App\Models\PostContent;
use Tests\TestCase;

class PostTest extends TestCase
{
    public function testGetNextPost()
    {
    }
}