<?php

return [

    'your_account_has_been_locked' => '您的账号已被锁定',
    'no_permission' => '没有权限',
];
