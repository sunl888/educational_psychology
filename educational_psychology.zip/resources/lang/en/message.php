<?php

return [

    'your_account_has_been_locked' => 'Your account has been locked.',
    'no_permission' => 'No permission.',
];
