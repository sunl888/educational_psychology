<div class="download">
    <a {!! $category->getPresenter()->linkAttribute() !!}>
        <div class="text"><p>资料下载</p></div>
        <img src="{{cdn('edu/images/download.png')}}" alt="资料下载">
        <div class="mask"></div>
    </a>
</div>