import TTable from './TTable.vue';

export default TTable;
