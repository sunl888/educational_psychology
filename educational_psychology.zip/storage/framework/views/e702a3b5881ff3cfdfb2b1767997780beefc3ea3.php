<!-- 配置文件 -->
<script type="text/javascript" src="<?php echo e(asset('vendor/neditor/neditor.config.js')); ?>"></script>
<!-- 编辑器源码文件 -->
<script type="text/javascript" src="<?php echo e(asset('vendor/neditor/neditor.all.js')); ?>"></script>
<script>
    window.UEDITOR_CONFIG.serverUrl = '<?php echo e(route(config('ueditor.route.name'))); ?>'
</script>