<div class="widget">
    <h4>热门文章</h4>
    <ul class="content">
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li><a href="<?php echo $post->getPresenter()->url(); ?>"><?php echo $post->title; ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="no_data"><img src="<?php echo e(cdn('edu/images/no_data.png')); ?>" alt=""></p>
        <?php endif; ?>
    </ul>
</div>