<div class="header">
    <div class="mask"></div>
    <div class="main">
        <div class="left_name">
            <img src="<?php echo e(cdn('edu/images/logo.png')); ?>" class="logo">
            <img src="<?php echo e(cdn('edu/images/e_name.png')); ?>" class="e_name">
            <img src="<?php echo e(cdn('edu/images/c_name.png')); ?>" class="c_name">
        </div>
        <div class="right_img">
            <img src="<?php echo e(cdn('edu/images/right_img.png')); ?>" alt="">
        </div>
    </div>

</div>