<section data-id="case" class="zm-case zm-wrap">
    <div class="container">
        <header class="zm-title">
            <h3><?php echo $category->cate_name; ?></h3>
            <div class="line"></div>
            <p><?php echo $category->description; ?></p>
        </header>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-lg-3 col-sm-6 col-xs-6 case-item">
                <div class="main">
                    <div class="img-wrap">
                        <img lazy src="<?php echo image_url($post->cover, 'case_cover'); ?>">
                    </div>
                    <div class="body">
                        <h4><?php echo $post->getPresenter()->suitedTitle(); ?></h4>
                        <p><?php echo $post->excerpt; ?></p>
                        <div class="footer">
                            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="tag"><?php echo $tag->name; ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>