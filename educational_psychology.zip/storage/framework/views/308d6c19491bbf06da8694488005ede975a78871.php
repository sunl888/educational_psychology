
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <title>404</title>
    <style type="text/css">
        body{
            text-align: center;
        }
        h1{
            padding-top: 120px;
            font-weight: normal;
            font-size: 40px;
            color: #333;
            font-family: -apple-system, "Helvetica Neue", "Arial", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "WenQuanYi Micro Hei", sans-serif;
        }
        p{
            font-size: 18px;
        }
        a{
            text-decoration: none;
            color: #337ab7;
            margin-right: 10px;
        }
    </style>
</head>
<body>
<h1>404 没有找到相关内容</h1>
<?php
    $previous = URL::previous();
?>
<p>
    <?php if($previous != URL::current() && is_same_host($previous)): ?>
        <a href="<?php echo $previous; ?>">返回上一页</a>
    <?php endif; ?>
    <a href="<?php echo URL::to('/'); ?>">返回首页</a>发现好文章</p>
</body>
</html>