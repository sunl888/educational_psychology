<div class="pic_roll">
    <div class="title">
        <img src="<?php echo e(cdn('edu/images/pic.png')); ?>" alt="">
        <h2>学术队伍</h2>
    </div>
    <div class="pic_main">
        <ul class="pic_list">
            <?php
                // 当banner小于6个时前端轮播图会出现问题，因此在这里手动复制一个banner
                $count = $banners->count();
                if($count < 6){
                    for ($i = 1; $i <= 6-$count; $i++) {
                        $banners->push($banners[$i-1]);
                    }
                }
            ?>
            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo $banner->url; ?>">
                        <img src="<?php echo image_url($banner->image); ?>" alt="">
                        <p><?php echo e(isset($banner->title) ? $banner->title : ''); ?></p>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>