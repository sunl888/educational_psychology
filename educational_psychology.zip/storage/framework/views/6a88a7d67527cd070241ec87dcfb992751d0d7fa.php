<div class="left">
    <div class="title">
        <img src="<?php echo e(cdn('edu/images/news.png')); ?>" alt="新闻速递">
        <h2>新闻通告</h2>
        <a class="more" <?php echo $category->getPresenter()->linkAttribute(); ?>>更多</a>
    </div>
    <div class="content">
        <?php echo app('\App\Support\Widget\WidgetFactory')->render('image_post', ['category' => '新闻通告']); ?>
        <ul class="news_list">
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li>
                    <a href="<?php echo $post->getPresenter()->url(); ?>"><?php echo $post->title; ?></a>
                    <span><?php echo $post->published_at->format('Y-m-d'); ?></span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="no_data"><img src="<?php echo e(cdn('edu/images/no_data.png')); ?>" alt=""></p>
            <?php endif; ?>
        </ul>
    </div>
</div>