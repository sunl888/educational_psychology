<?php $__env->startSection('keywords'); ?><?php echo $page->getKeywords(); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo $page->getDescription(); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?><?php echo $page->title; ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make(THEME_NP.'.layouts.particals.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo app('\App\Support\Widget\WidgetFactory')->render('navigation_bar'); ?>
        <div class="list_page">
            <div class="left_sidebar">
                <?php echo app('\App\Support\Widget\WidgetFactory')->render('hot_post_list'); ?>
                <?php echo $__env->make(THEME_NP.'layouts.particals.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="right_list">
                <div class="header">
                    <?php echo Breadcrumbs::render('category', $category); ?>

                </div>
                <div class="right_main">
                    <div class="title_container">
                        <h1><?php echo $page->title; ?></h1>
                        <p class="info">
                            <span><?php echo $page->published_at->format('Y年m月d日'); ?></span>
                            <span><?php echo $page->views_count; ?> 人阅读</span>
                            <span class="avatar">
                    上传：<span class="uname"><?php echo isset($page->user->nick_name)?$page->user->nick_name:$page->user->user_name; ?></span>
                </span>
                        </p>
                    </div>
                    <div class="content">
                        <?php echo $page->postContent->content; ?>

                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make(THEME_NP.'.layouts.particals.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make(THEME_NP.'.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>