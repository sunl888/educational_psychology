<section class="zm-link zm-wrap">
    <header class="zm-title">
        <h3>友情链接</h3>
        <div class="line"></div>
    </header>
    <div class="container">
        <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="link-item col-md-2 col-lg-2 col-sm-6 col-xs-6" href="<?php echo $link->url; ?>"  title="<?php echo $link->name; ?>" target="_blank"><img src="<?php echo image_url($link->logo); ?>" alt="<?php echo $link->name; ?>"></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>