<?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo $link->url; ?>" title="<?php echo $link->name; ?>" target="_blank"><img
                lazy src="<?php echo image_url($link->logo, 'avatar_xs'); ?>"
                alt="<?php echo $link->name; ?>"><span><?php echo $link->name; ?></span></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>