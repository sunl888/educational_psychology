<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php $__env->startSection('description'); ?><?php echo $__env->yieldSection(); ?>">
    <meta name="keywords" content="<?php $__env->startSection('keywords'); ?><?php echo $__env->yieldSection(); ?>">
    <title><?php $__env->startSection('title'); ?>tiny <?php echo $__env->yieldSection(); ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(cdn(mix('static/css/app.css'))); ?>">
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
<?php echo $__env->yieldContent('content'); ?>
<script src="<?php echo e(cdn(mix('static/js/app.js'))); ?>"></script>
<?php echo $__env->yieldContent('js'); ?>
<?php echo $__env->yieldPushContent('js'); ?>
</body>
</html>