<div class="header_nav">
    <ul>
        <li>
            <a <?php echo is_null($navigation->getActiveTopNav())?' class="active"':''; ?> href="<?php echo route('frontend.web.index'); ?>">首页</a>
        </li>
        <?php $__currentLoopData = $allNav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a title="<?php echo $category->cate_name; ?>" <?php echo $category->is($navigation->getActiveTopNav())?' class="active"':''; ?> <?php echo $category->getPresenter()->linkAttribute(); ?>><?php echo $category->cate_name; ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>