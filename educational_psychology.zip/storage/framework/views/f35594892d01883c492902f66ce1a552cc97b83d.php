<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- 前台 URL -->
    <meta name="frontend_url" content="<?php echo route('frontend.web.index'); ?>">
    <title>tiny</title>
</head>
<body>
<div id="app"></div>
<script>
    window.logo = "<?php echo e(config('tiny.logo', 'tiny')); ?>";
</script>
<script src="<?php echo e(cdn('onlyGetPost.js')); ?>"></script>
<?php echo $__env->make('vendor.ueditor.assets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script src="<?php echo e(cdn(mix('js/backend/app.js'))); ?>"></script>
</body>
</html>
