<div class="right_main">
    <ul class="text_list">
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li>
                <a href="<?php echo $post->getPresenter()->url(); ?>" title="<?php echo $post->title; ?>"><?php echo $post->title; ?></a>
                <span class="time"><?php echo $post->published_at->format('Y-m-d'); ?></span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="no_data"><img src="<?php echo e(cdn('edu/images/no_data.png')); ?>" alt=""></p>
        <?php endif; ?>
    </ul>
    <!-- 分页 -->
    <div class="page_body">
        <?php echo $posts->fragment('list')->links('vendor.pagination.default'); ?>

    </div>
</div>