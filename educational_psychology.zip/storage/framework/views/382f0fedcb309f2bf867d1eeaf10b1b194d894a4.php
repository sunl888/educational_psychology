<div class="nav_menu">
    <ul>
        <li <?php if($navigation->getActiveNav()->equals($navigation->getActiveTopNav())): ?>class="active"<?php endif; ?>>
            <span class="pendant"></span>
            <a title="<?php echo $navigation->getActiveTopNav()->cate_name; ?>" <?php echo $navigation->getActiveTopNav()->getPresenter()->linkAttribute(); ?>><?php echo $navigation->getActiveTopNav()->cate_name; ?></a>
            <span class="arrow"></span>
        </li>
        <?php $__currentLoopData = $navigation->getActiveChildrenNav(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childNav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li <?php if($childNav->equals($navigation->getActiveNav())): ?>class="active"<?php endif; ?>>
                <span class="pendant"></span>
                <a title="<?php echo $childNav->cate_name; ?>" <?php echo $childNav->getPresenter()->linkAttribute(); ?>><?php echo $childNav->cate_name; ?></a>
                <span class="arrow"></span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>