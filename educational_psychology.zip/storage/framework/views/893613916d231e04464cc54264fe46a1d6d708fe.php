<?php
$homeUrl = route('frontend.web.index');
?>
<?php $__env->startPush('js'); ?>
<script>
    $(function () {
        var $menuXs = $('#menu-xs');
        $('#btn-toggle').click(function(){
            $menuXs.toggle();
        });
    })
</script>
<?php $__env->stopPush(); ?>
<nav class="nav<?php echo isset($normalPage)?' small':''; ?>" id="nav">
    <div class="container">
        <div class="logo">
            <a href="<?php echo $homeUrl; ?>"><?php echo e(setting('site_name')); ?></a>
        </div>
        <ul class="menu">
            <li><a href="<?php echo $homeUrl; ?>">首页</a></li>
            <li><a href="<?php echo $homeUrl; ?>#case">案例</a></li>
            <li><a href="<?php echo $homeUrl; ?>#news">新闻</a></li>
            <li><a href="<?php echo $homeUrl; ?>#team">团队</a></li>
            <li><a href="<?php echo $homeUrl; ?>#skill">技术栈</a></li>
            <li><a href="<?php echo $homeUrl; ?>#contact">联系我们</a></li>
            <li><a href="<?php echo $homeUrl; ?>#join">加入我们</a></li>
        </ul>
        <button type="button" id="btn-toggle" class="navbar-toggle collapsed">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <ul id="menu-xs" class="menu-xs">
            <li><a href="<?php echo $homeUrl; ?>">首页</a></li>
            <li><a href="<?php echo $homeUrl; ?>#case">案例</a></li>
            <li><a href="<?php echo $homeUrl; ?>#news">新闻</a></li>
            <li><a href="<?php echo $homeUrl; ?>#team">团队</a></li>
            <li><a href="<?php echo $homeUrl; ?>#skill">技术栈</a></li>
            <li><a href="<?php echo $homeUrl; ?>#contact">联系我们</a></li>
            <li><a href="<?php echo $homeUrl; ?>#join">加入我们</a></li>
        </ul>
    </div>
    <div class="mask"></div>
</nav>
