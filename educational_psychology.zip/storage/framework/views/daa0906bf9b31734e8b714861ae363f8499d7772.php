<div class="img_news">
    <?php $__empty_1 = true; $__currentLoopData = $image_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="<?php echo $post->getPresenter()->url(); ?>">
            <img src="<?php echo image_url($post->cover); ?>" alt="">
            <div class="info">
                <h2><?php echo $post->title; ?></h2>
                <p><?php echo $post->excerpt; ?></p>
            </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="no_data"><img src="<?php echo e(cdn('edu/images/no_data.png')); ?>" alt=""></p>
    <?php endif; ?>

</div>