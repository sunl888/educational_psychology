<?php $__env->startSection('keywords'); ?><?php echo $keywords; ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo $keywords; ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?><?php echo e(Breadcrumbs::pageTitle(' - ', 'search', $keywords)); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <!-- 头部 -->
    <?php echo $__env->make(THEME_NP.'.layouts.particals.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- 导航栏 -->
        <?php echo app('\App\Support\Widget\WidgetFactory')->render('navigation_bar'); ?>
        <!-- 中间部分 -->
        <div class="list_page">
            <div class="left_sidebar">
                <?php echo app('\App\Support\Widget\WidgetFactory')->render('hot_post_list'); ?>
                <?php echo $__env->make(THEME_NP.'layouts.particals.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="right_list">
                <div class="header">
                    <?php echo e(Breadcrumbs::view(THEME_NP.'.layouts.particals.search_breadcrumbs', 'search', $keywords)); ?>

                </div>
                <div class="right_main">
                    <ul class="text_list">
                        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li>
                                <a href="<?php echo $post->getPresenter()->url(); ?>"
                                   title="<?php echo $post->title; ?>"><?php echo sign_color($post->title, $keywords); ?></a>
                                <span class="time"><?php echo $post->published_at->format('Y-m-d'); ?></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="no_data"><img src="<?php echo e(cdn('edu/images/no_data.png')); ?>" alt=""></p>
                        <?php endif; ?>
                    </ul>
                    <!-- 分页 -->
                    <div class="page_body">
                        <?php echo $posts->fragment('list')->appends('keywords', $keywords)->links('vendor.pagination.default'); ?>

                    </div>
                </div>
            </div>
        </div>
        <!-- 底部导航 -->
        <?php echo $__env->make(THEME_NP.'.layouts.particals.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make(THEME_NP.'.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>