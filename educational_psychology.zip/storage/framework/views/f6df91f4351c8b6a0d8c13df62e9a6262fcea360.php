<div class="right">
    <div class="title">
        <img src="<?php echo e(cdn('edu/images/notice.png')); ?>" alt="">
        <h2>科学研究</h2>
        <a class="more" <?php echo $category->getPresenter()->linkAttribute(); ?>>更多</a>
    </div>
    <ul class="notice_list">
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li>
                <div class="date">
                    <p class="year"><?php echo $post->published_at->format('Y'); ?></p>
                    <p class="m_d"><?php echo $post->published_at->format('m/d'); ?></p>
                </div>
                <a href="<?php echo $post->getPresenter()->url(); ?>"><?php echo $post->title; ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="no_data"><img src="<?php echo e(cdn('edu/images/no_data.png')); ?>" alt=""></p>
        <?php endif; ?>
    </ul>
    
    <?php echo app('\App\Support\Widget\WidgetFactory')->render('post_list', ['category' => '资料下载', 'view' => 'post_lists.download', 'limit' => 1]); ?>
</div>