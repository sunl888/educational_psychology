<div class="download">
    <a <?php echo $category->getPresenter()->linkAttribute(); ?>>
        <div class="text"><p>资料下载</p></div>
        <img src="<?php echo e(cdn('edu/images/download.png')); ?>" alt="资料下载">
        <div class="mask"></div>
    </a>
</div>