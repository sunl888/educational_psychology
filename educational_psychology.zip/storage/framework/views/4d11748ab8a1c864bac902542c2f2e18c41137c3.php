<div class="footer_nav">
    <div class="content">
        <?php echo app('\App\Support\Widget\WidgetFactory')->render('link', ['type' => 'friendship_links']); ?>
        <div class="footer_text">
            <img src="<?php echo cdn('edu/images/footer_nav_text.png'); ?>" alt="">
        </div>
        <ul class="right_info">
            <li>地址：<?php echo e(setting('address')); ?></li>
            <li>邮编：<?php echo e(setting('zip_code')); ?></li>
            <li>联系电话：<?php echo e(setting('phone')); ?></li>
            <li>版权所有 © <?php echo e(setting('copyright')); ?></li>
        </ul>
    </div>
    <div class="mask"></div>
</div>
<div class="mast_footer">
    <span>技术支持：<?php echo e(setting('support')); ?></span>
    <span>您是第 1 个访问者</span>
</div>