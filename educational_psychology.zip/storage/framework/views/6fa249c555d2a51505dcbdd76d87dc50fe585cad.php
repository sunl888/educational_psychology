<section data-id="team" class="zm-team zm-wrap">
    <div class="container">
        <header class="zm-title white">
            <h3><?php echo $category->cate_name; ?></h3>
            <div class="line"></div>
            <p><?php echo $category->description; ?></p>
        </header>
        <div id="teams">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="team-item">
                    <div class="team-main">
                        <div class="avatar">
                            <img lazy src="<?php echo image_url($post->cover, 'avatar_md'); ?>">
                        </div>
                        <h4><?php echo $post->title; ?></h4>
                        <div class="tags">
                            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="tag"><?php echo $tag->name; ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <p class="info"><?php echo $post->excerpt; ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="button_wrap">
        <a class="btn more_btn"<?php echo $category->getPresenter()->linkAttribute(); ?>>查看更多<i class="glyphicon glyphicon-chevron-right"></i></a>
    </div>
</section>
<?php $__env->startPush('js'); ?>
<script>
    $(function () {
        $teams = $('#teams');
        if ($teams.children().length == 0)
            return;
        $teams.slick({
            dots: true,
            infinite: true,
            centerMode: true,
            variableWidth: true,
            autoplay: true,
            autoplaySpeed: 5000,
            slidesToShow: 3,
            slidesToScroll: 3,
            arrows: true
        });
    })
</script>
<?php $__env->stopPush(); ?>