<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="description" content="<?php $__env->startSection('description'); ?><?php echo $__env->yieldSection(); ?>">
    <meta name="keywords" content="<?php $__env->startSection('keywords'); ?><?php echo $__env->yieldSection(); ?>">
    <title><?php $__env->startSection('title'); ?> <?php echo $__env->yieldSection(); ?> 教育心理学</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(cdn('edu/css/comm.css')); ?>">
</head>
<body>
<?php echo $__env->yieldContent('content'); ?>
<script type="text/javascript" src="<?php echo cdn('edu/lib/jquery/jquery.min.js'); ?>"></script>
<?php echo $__env->yieldPushContent('js'); ?>
</body>
</html>