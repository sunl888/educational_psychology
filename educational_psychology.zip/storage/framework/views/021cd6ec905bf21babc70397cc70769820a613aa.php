<?php $__env->startSection('keywords'); ?><?php echo $category->getKeywords(); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo $category->getDescription(); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?><?php echo e(Breadcrumbs::pageTitle(' - ', 'category', $category)); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <!-- 头部 -->
    <?php echo $__env->make(THEME_NP.'.layouts.particals.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- 导航栏 -->
        <?php echo app('\App\Support\Widget\WidgetFactory')->render('navigation_bar'); ?>
        <!-- 中间部分 -->
        <div class="list_page">
            <div class="left_sidebar">
                <?php echo app('\App\Support\Widget\WidgetFactory')->render('hot_post_list'); ?>
                <?php echo $__env->make(THEME_NP.'layouts.particals.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="right_list">
                <div class="header">
                    <?php echo e(Breadcrumbs::render('category', $category)); ?>

                </div>
                <?php echo app('\App\Support\Widget\WidgetFactory')->render('post_list', ['category' => $category->cate_name, 'view' => 'post_lists.default_list', 'limit' => 7]); ?>
            </div>
        </div>
        <!-- 底部导航 -->
        <?php echo $__env->make(THEME_NP.'.layouts.particals.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make(THEME_NP.'.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>