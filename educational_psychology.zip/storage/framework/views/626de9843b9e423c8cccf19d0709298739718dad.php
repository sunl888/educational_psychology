<?php $__env->startPush('js'); ?>
    <script>
      $('#nav>li').hover(function () {
        var $list = $(this).find('.child')
        $list.css('display', 'block');
        $list.stop().animate({
          'opacity': 1,
          'top': '60px'
        }, 200)
      }, function () {
        var $list = $(this).find('.child')
        $list.stop().animate({
          'opacity': 0,
          'top': '80px'
        }, 200, function () {
          if($list.css('top') == '70px'){
            $list.css('display', 'none');
          }
        })
      });
      $(function () {
        var $searchForm = $('#search_form');
        $searchForm.find('input').keydown(function (e) {
          if (e.keyCode == 13) {
            $searchForm.submit();
          }
        })
      })
    </script>
<?php $__env->stopPush(); ?>
<div class="head">
    <div class="container">
        <a class="logo" href="#"><img src="<?php echo cdn('jiegao/images/logo.png'); ?>" alt="<?php echo e(setting('site_name')); ?>"></a>
        <div class="right">
            <span>服务热线：<?php echo e(setting('phone')); ?></span>
            <div class="search">
                <form id="search_form" action="<?php echo e(route('frontend.web.search')); ?>" method="GET">
                    <input id="search_input" placeholder="请输入关键字搜索.." type="text" name="keywords">
                    <i class="search_icon" onclick="this.parentElement.submit()"></i>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="nav">
    <div class="container">
        <ul id="nav">
            <li>
                <a <?php echo is_null($navigation->getActiveTopNav())?' class="active"':''; ?> href="<?php echo route('frontend.web.index'); ?>">网站首页</a>
            </li>
            <?php $__currentLoopData = $allNav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a title="<?php echo $category->cate_name; ?>" <?php echo $category->equals($navigation->getActiveTopNav())?' class="active"':''; ?> <?php echo $category->getPresenter()->linkAttribute(); ?>><?php echo $category->cate_name; ?></a>
                    <?php if($category->hasChildren()): ?>
                        <div class="child">
                            <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a title="<?php echo $children->cate_name; ?>" class="item"<?php echo $children->getPresenter()->linkAttribute(); ?>><?php echo $children->cate_name; ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
