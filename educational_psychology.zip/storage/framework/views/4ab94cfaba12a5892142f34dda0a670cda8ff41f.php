<?php $__env->startSection('keywords'); ?><?php echo $post->getKeywords(); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo $post->getDescription(); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?><?php echo $post->title; ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make(THEME_NP.'.layouts.particals.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo app('\App\Support\Widget\WidgetFactory')->render('navigation_bar'); ?>
        <div class="list_page">
            <div class="left_sidebar">
                <?php echo app('\App\Support\Widget\WidgetFactory')->render('hot_post_list'); ?>
                <?php echo $__env->make(THEME_NP.'layouts.particals.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="right_list">
                <div class="header">
                    <?php echo Breadcrumbs::render('post', $post); ?>

                </div>
                <div class="right_main">
                    <div class="title_container">
                        <h1><?php echo $post->title; ?></h1>
                        <p class="info">
                            <span><?php echo $post->published_at->format('Y年m月d日'); ?></span>
                            <span><?php echo $post->views_count; ?> 人阅读</span>
                            <span class="avatar">
                    上传：<span class="uname"><?php echo isset($post->user->nick_name)?$post->user->nick_name:$post->user->user_name; ?></span>
                </span>
                        </p>
                    </div>
                    <div class="content">
                        <?php echo $post->postContent->content; ?>

                    </div>
                    <div class="recommend">
                        <p>上一篇：<a href="<?php echo e($post->getPreviousPost()?$post->getPreviousPost()->getPresenter()->url():''); ?>"><?php echo e($post->getPreviousPost()?$post->getPreviousPost()->title:'没有了'); ?></a></p>
                        <p>下一篇：<a href="<?php echo e($post->getNextPost()?$post->getNextPost()->getPresenter()->url():''); ?>"><?php echo e($post->getNextPost()?$post->getNextPost()->title:'没有了'); ?></a></p>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make(THEME_NP.'.layouts.particals.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make(THEME_NP.'.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>