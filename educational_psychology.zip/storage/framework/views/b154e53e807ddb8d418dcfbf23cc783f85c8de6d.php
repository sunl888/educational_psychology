
<?php $__env->startSection('keywords'); ?><?php echo e(setting('default_keywords')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e(setting('default_description')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?><?php echo e(setting('site_name')); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <!-- 头部 -->
        <div class="header">
            <div class="left_name">
                <img src="./images/e_name.png" class="e_name">
                <img src="./images/c_name.png" class="c_name">
            </div>
            <div class="right_img">
                <img src="./images/right_img.png" alt="">
            </div>
        </div>
        <!-- 导航栏 -->
        <div class="header_nav">
            <ul>
                <li><a href="javascript:;">首页</a></li>
                <li><a href="javascript:;">学科方向</a></li>
                <li><a href="javascript:;">学术队伍</a></li>
                <li><a href="javascript:;">科学研究</a></li>
                <li><a href="javascript:;">人才培养</a></li>
                <li><a href="javascript:;">学术交流</a></li>
                <li><a href="javascript:;">课程建设</a></li>
                <li><a href="javascript:;">支撑条件</a></li>
                <li><a href="javascript:;">规章制度</a></li>
                <li><a href="javascript:;">学术动态</a></li>
                <li><a href="javascript:;">合作交流</a></li>
            </ul>
        </div>
        <!-- 中间内容 -->
        <div class="index_content">
            <div class="left">
                <div class="title">
                    <img src="./images/news.png" alt="">
                    <h2>新闻速递</h2>
                    <a class="more" href="javascript:;">更多</a>
                </div>
                <div class="content">
                    <div class="img_news">
                        <a href="javascript:;">
                            <img src="./images/new.png" alt="">
                            <div class="info">
                                <h2>清华大学核电国际硕士项目赴沙特招生宣传圆满结束</h2>
                                <p>1月7-13日，清华大学核电工程与管理国际人才培养专业硕士学位项目（TUNEM）代表团赴土耳其进行招生宣传。</p>
                            </div>
                        </a>
                    </div>
                    <ul class="news_list">
                        <li>
                            <a href="javascript:;">清华大学核电国际硕士项目赴沙特招生宣传圆满结束</a>
                            <span>2018-02-27</span>
                        </li>
                        <li>
                            <a href="javascript:;">清华大学核电国际硕士项目赴沙特招生宣传圆满结束</a>
                            <span>2018-02-27</span>
                        </li>
                        <li>
                            <a href="javascript:;">清华大学核电国际硕士项目赴沙特招生宣传圆满结束</a>
                            <span>2018-02-27</span>
                        </li>
                        <li>
                            <a href="javascript:;">清华大学核电国际硕士项目赴沙特招生宣传圆满结束</a>
                            <span>2018-02-27</span>
                        </li>
                        <li>
                            <a href="javascript:;">清华大学核电国际硕士项目赴沙特招生宣传圆满结束</a>
                            <span>2018-02-27</span>
                        </li>
                        <li>
                            <a href="javascript:;">清华大学核电国际硕士项目赴沙特招生宣传圆满结束</a>
                            <span>2018-02-27</span>
                        </li>
                        <li>
                            <a href="javascript:;">清华大学核电国际硕士项目赴沙特招生宣传圆满结束</a>
                            <span>2018-02-27</span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="right">
                <div class="title">
                    <img src="./images/notice.png" alt="">
                    <h2>通知通告</h2>
                    <a class="more" href="javascript:;">更多</a>
                </div>
                <ul class="notice_list">
                    <li>
                        <div class="date">
                            <p class="year">2017</p>
                            <p class="m_d">04/19</p>
                        </div>
                        <a href="javascript:;">2018年清华大学硕士生入学考试工程物理系复试方案</a>
                    </li>
                    <li>
                        <div class="date">
                            <p class="year">2017</p>
                            <p class="m_d">04/19</p>
                        </div>
                        <a href="javascript:;">2018年清华大学硕士生入学考试工程物理系复试方案</a>
                    </li>
                    <li>
                        <div class="date">
                            <p class="year">2017</p>
                            <p class="m_d">04/19</p>
                        </div>
                        <a href="javascript:;">2018年清华大学硕士生入学考试工程物理系复试方案</a>
                    </li>
                    <li>
                        <div class="date">
                            <p class="year">2017</p>
                            <p class="m_d">04/19</p>
                        </div>
                        <a href="javascript:;">2018年清华大学硕士生入学考试工程物理系复试方案</a>
                    </li>
                </ul>
                <div class="download">
                    <a href="javascript:;">
                        <div class="text"><p>资料下载</p></div>
                        <img src="./images/download.png" alt="">
                        <div class="mask"></div>
                    </a>
                </div>
            </div>
        </div>
        <!-- 图片滚动 -->
        <div class="pic_roll">
            <div class="title">
                <img src="./images/pic.png" alt="">
                <h2>学术队伍</h2>
            </div>
            <div class="pic_main">
                <ul class="pic_list">
                    <li>
                        <a href="javascript:;">
                            <img src="./images/pic/pic1.jpg" alt="">
                            <p>这是一句介绍</p>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:;">
                            <img src="./images/pic/pic2.jpg" alt="">
                            <p>这是一句介绍</p>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:;">
                            <img src="./images/pic/pic3.jpg" alt="">
                            <p>这是一句介绍</p>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:;">
                            <img src="./images/pic/pic4.jpg" alt="">
                            <p>这是一句介绍</p>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:;">
                            <img src="./images/pic/pic3.jpg" alt="">
                            <p>这是一句介绍</p>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:;">
                            <img src="./images/pic/pic2.jpg" alt="">
                            <p>这是一句介绍</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="footer_nav">
            <div class="content">
                <ul class="left_nav">
                    <li><a href="javascript:;">学科方向</a></li>
                    <li><a href="javascript:;">学术队伍</a></li>
                    <li><a href="javascript:;">科学研究</a></li>
                    <li><a href="javascript:;">人才培养</a></li>
                    <li><a href="javascript:;">学术交流</a></li>
                    <li><a href="javascript:;">学科方向</a></li>
                    <li><a href="javascript:;">学术交流</a></li>
                    <li><a href="javascript:;">学科方向</a></li>
                </ul>
                <div class="footer_text">
                    <img src="./images/footer_nav_text.png" alt="">
                </div>
                <ul class="right_info">
                    <li>地址：安徽省淮南市洞山西路</li>
                    <li>邮编：232038</li>
                    <li>联系电话：0554-6863832</li>
                    <li>版权所有 © 淮南师范学院教育学院</li>
                </ul>
            </div>
            <div class="mask"></div>
        </div>
        <div class="mast_footer">
            <span>技术支持：E8net. powered by tiny</span>
            <span>您是第 302304 个访问者</span>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script type="text/javascript">
        $(function () {
            // 图片滚动
            var $picContainer = $(".pic_list");
            var $imgList = $(".pic_list>li");
            var productTimer = null;
            $picContainer.width($imgList[0].offsetWidth * $imgList.length);

            function move() {
                var current = $picContainer.css("transform").replace(/[^0-9\-,]/g, '').split(',')[4] - 1;
                $picContainer.css("transform", "translateX(" + current + "px)");
                if (current <= -200) {
                    $picContainer.css("transform", "translateX(0px)");
                    $picContainer.append($picContainer.children().first());
                }
            }

            productTimer = setInterval(function () {
                move();
            }, 20)

            $picContainer.hover(function () {
                clearInterval(productTimer);
            }, function () {
                productTimer = setInterval(function () {
                    move();
                }, 20)
            })
        }())
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('edu.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>