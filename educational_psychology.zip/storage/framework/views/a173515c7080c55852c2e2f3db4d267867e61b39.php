<?php $__env->startSection('keywords'); ?><?php echo e(setting('default_keywords')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e(setting('default_description')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?><?php echo e(setting('site_name')); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <!-- 头部 -->
        <?php echo $__env->make(THEME_NP.'.layouts.particals.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- 导航栏 -->
        <?php echo app('\App\Support\Widget\WidgetFactory')->render('navigation_bar'); ?>
        <!-- 中间内容 -->
        <div class="index_content">
            
            <?php echo app('\App\Support\Widget\WidgetFactory')->render('post_list', ['category' => '新闻通告', 'view' => 'post_lists.news_list', 'limit' => 7]); ?>
            
            <?php echo app('\App\Support\Widget\WidgetFactory')->render('post_list', ['category' => '科学研究', 'view' => 'post_lists.notice_list', 'limit' => 4]); ?>
        </div>
        <!-- 图片滚动 -->
        <?php echo app('\App\Support\Widget\WidgetFactory')->render('banner', ['type'=>'categorys']); ?>
        
        <?php echo $__env->make(THEME_NP.'.layouts.particals.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script type="text/javascript">
        $(function () {
            // 图片滚动
            var $picContainer = $(".pic_list");
            var $imgList = $(".pic_list>li");
            var productTimer = null;
            $picContainer.width($imgList[0].offsetWidth * $imgList.length);

            function move() {
                var left = $picContainer.css('left');
                var currentLeft = parseInt(left.substring(0, left.length - 2));
                $picContainer.css('left', currentLeft - 1);
                if (currentLeft <= -200) {
                    $picContainer.css('left', 0);
                    $picContainer.append($picContainer.find('li').first());
                }
            }

            productTimer = setInterval(move, 20);

            $picContainer.hover(function () {
                clearInterval(productTimer);
            }, function () {
                productTimer = setInterval(move, 20)
            })
        }())
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make(THEME_NP.'.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>