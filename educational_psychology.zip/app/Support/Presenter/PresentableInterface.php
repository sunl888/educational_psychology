<?php

namespace App\Support\Presenter;

interface PresentableInterface
{
    public function getPresenter();
}
