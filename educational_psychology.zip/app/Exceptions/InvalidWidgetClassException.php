<?php

namespace App\Exceptions;

use Exception;

class InvalidWidgetClassException extends Exception
{

}
