<?php

namespace App\Exceptions;


use Exception;

class RepositoryException extends Exception
{

}
